import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListAllOrdersComponent } from './list-all-orders/list-all-orders.component';
import { ViewOrderDetailsComponent } from './view-order-details/view-order-details.component';
import { EditOrderDetailsComponent } from './edit-order-details/edit-order-details.component';
import { RemoveBooksComponent } from './remove-books/remove-books.component';
import { AddBooksComponent } from './add-books/add-books.component';


const routes: Routes = [
  {path:'listAllOrder',component:ListAllOrdersComponent},
  {path:'viewOrder',component:ViewOrderDetailsComponent},
  {path:'editOrder/:id',component:EditOrderDetailsComponent},
  {path:'removeBook',component:RemoveBooksComponent},
  {path:'addBook',component:AddBooksComponent},
  {path:'',redirectTo:"/listAllOrder",pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
