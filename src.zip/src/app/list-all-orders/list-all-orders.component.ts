import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog,MatDialogConfig  } from '@angular/material/dialog';
import { DeleteConfirmDialogComponent } from '../delete-confirm-dialog/delete-confirm-dialog.component';
import { OrderInformationService } from '../order-information.service';
import { orderInformation } from '../data';



@Component({
  selector: 'app-list-all-orders',
  templateUrl: './list-all-orders.component.html',
  styleUrls: ['./list-all-orders.component.css']
})
export class ListAllOrdersComponent implements OnInit {
  
  result:String;
  order:orderInformation[]=[]

  constructor(private router: Router ,public dialog: MatDialog,private orderInformation:OrderInformationService) { }

  ngOnInit() {
    this.orderInformation.listAllOrder().subscribe(data=>{this.order=data});
    
  }
  viewOrder(orderId:number){
    this.orderInformation.setOrderId(orderId);
    this.router.navigate(['viewOrder'])
  }

  editOrder(orderId:number)
  {
    this.orderInformation.setOrderId(orderId);
    this.router.navigate(['editOrder'])

  }

  deleteOrder(Id:number)
  {
   
   console.log("openDialog");
    let dialogRef = this.dialog.open(DeleteConfirmDialogComponent, {

      data:{
          orderId:Id
      }
    });
    
    dialogRef.afterClosed().subscribe(result=>{
      console.log("Closed");
      if(result=="yes"){
        console.log("Closed");
        this.orderInformation.CancleOrder(Id).subscribe(data=>{this.result=data});
        console.log(this.result);
        location.reload();
      }
      
    });
    
    
  }



 
}
