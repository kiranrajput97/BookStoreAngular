import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-books',
  templateUrl: './remove-books.component.html',
  styleUrls: ['./remove-books.component.css']
})
export class RemoveBooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
