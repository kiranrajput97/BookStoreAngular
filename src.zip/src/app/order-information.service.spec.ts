import { TestBed } from '@angular/core/testing';

import { OrderInformationService } from './order-information.service';

describe('OrderInformationService', () => {
  let service: OrderInformationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OrderInformationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
