import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrderInformationService } from '../order-information.service';
import { orderInformation, BookInformation, CartInformation } from '../data';

@Component({
  selector: 'app-edit-order-details',
  templateUrl: './edit-order-details.component.html',
  styleUrls: ['./edit-order-details.component.css']
})
export class EditOrderDetailsComponent implements OnInit 

{
  order_curr: orderInformation;

  newShippingAddress: String;
  newRecipientName: String;
  newRecipientPhone: String;
  newOrderStatus: String;
  newQuantity: number;
  orderId:number;
  msg:string;
  errorMsg:string;
  
  cartlist:CartInformation[];
  books_curr: BookInformation;
  

  constructor(private route: ActivatedRoute,
    private router: Router,
    private  orderServe: OrderInformationService) { }

  ngOnInit() {
    this.orderId=this.orderServe.getOrderId();
    this.orderServe.ViewOrder(this.orderId).subscribe(data=>{this.order_curr=data;console.log(this.order_curr);
      this.cartlist=this.order_curr.cart;
      console.log(this.cartlist);});
   
  }

  

  cancelRedirect(){
    this.router.navigate(['listAllOrder']);
  }
  updateOrder():void
  {
    if(this.newShippingAddress)
        this.order_curr.shippingAddress = this.newShippingAddress;
    if(this.newRecipientName)
        this.order_curr.recipientName = this.newRecipientName;
    
    if(this.newRecipientPhone)
        this.order_curr.recipientPhoneNumber = this.newRecipientPhone;

    if(this.newOrderStatus)
        this.order_curr.orderStatus = this.newOrderStatus;

    if(this.newQuantity)
        this.order_curr.quantity = this.newQuantity;
   
    this.orderServe.updateOrder(this.order_curr.orderId,this.order_curr).subscribe(data=>
      {
        alert("Order updated succesfully");
        this.router.navigateByUrl('editOrder/'+this.order_curr.orderId);
      },
      error=>
      {
        alert('OrderNotFound | Order does not present in database');
        console.log("error occured",error);
      }
    );
  }

  deleteBook( orderId:number,cartId:number){
    console.log(orderId,cartId);
    this.orderServe.deleteBook(orderId,cartId).subscribe(data=>{this.msg=data,console.log(this.msg);},
    error=>{this.errorMsg=error.error.message});
    alert("Book Is deleted")
    this.router.navigateByUrl("/listAllOrder");
  }

}