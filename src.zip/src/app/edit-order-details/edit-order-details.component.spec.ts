import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditOrderDetailsComponent } from './edit-order-details.component';

describe('EditOrderDetailsComponent', () => {
  let component: EditOrderDetailsComponent;
  let fixture: ComponentFixture<EditOrderDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditOrderDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditOrderDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
