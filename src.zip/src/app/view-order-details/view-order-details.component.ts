import { Component, OnInit } from '@angular/core';
import { orderInformation, CartInformation } from '../data';
import { OrderInformationService } from '../order-information.service';

@Component({
  selector: 'app-view-order-details',
  templateUrl: './view-order-details.component.html',
  styleUrls: ['./view-order-details.component.css']
})
export class ViewOrderDetailsComponent implements OnInit {

  
  order:orderInformation;
  cartlist:CartInformation[];
  
   orderId:number;
  constructor(private orderInformation:OrderInformationService) { }

  ngOnInit() {
    this.orderId=this.orderInformation.getOrderId();
    this.orderInformation.ViewOrder(this.orderId).subscribe(data=>{this.order=data;console.log(this.order);
      this.cartlist=this.order.cart;
      console.log(this.cartlist);});

    
  }

}
