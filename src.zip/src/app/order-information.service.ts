import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { orderInformation, BookInformation } from './data';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class OrderInformationService {

  constructor(private http: HttpClient) { }

  CancleOrder(orderId:number):Observable<any>{
    console.log(orderId);
    return this.http.get("http://localhost:8084/cancelOrder/"+orderId);
}

listAllOrder():Observable<any>{
  return this.http.get("http://localhost:8084/listOrders");
}

updateOrder(orderId: number,order: orderInformation){
  return this.http.put("http://localhost:8084/update_order/"+orderId,order);
}

deleteBook(orderId:number,cartId:number){
  
  console.log(orderId,cartId);
  return this.http.delete("http://localhost:8084/removebook/"+orderId+"/"+cartId,{responseType:'text'});
}

getOrder(id: number): Observable<orderInformation> {
  return this.listAllOrder()
    .pipe(
      map((orderInformation: orderInformation[]) => orderInformation.find(o => o.orderId === id))
    );
}


ViewOrder(orderId:number):Observable<any>{
  return this.http.get("http://localhost:8084/viewOrderDetailsById/"+orderId);
}
//set and get order id
Id:number;
setOrderId(orderId:number)
{
this.Id=orderId;
}
getOrderId()
{
return this.Id;
}

}